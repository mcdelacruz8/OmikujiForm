package com.matthew.omikuji.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class OmikujiFormController {

	// home page showing form
	@RequestMapping("/omikuji")
	public String home() {
		return "index.jsp";
	}

	@RequestMapping(value = "/sendInfo", method = RequestMethod.POST)
	public String sendInfo(
			// variables for each submitted value from form
			@RequestParam(value = "number") Integer number, @RequestParam(value = "city") String city,
			@RequestParam(value = "person") String person, @RequestParam(value = "hobby") String hobby,
			@RequestParam(value = "livingThing") String livingThing, @RequestParam(value = "nice") String nice,
			HttpSession sesh) {
		// submits value as the key and variable as the value
		sesh.setAttribute("number", number);
		sesh.setAttribute("city", city);
		sesh.setAttribute("person", person);
		sesh.setAttribute("hobby", hobby);
		sesh.setAttribute("livingThing", livingThing);
		sesh.setAttribute("nice", nice);
		// make sure to always redirect when using a POST request
		return "redirect:/omikuji/show";
	}
	
	@RequestMapping("/omikuji/show")
	public String show(HttpSession sesh, Model model) {
		// assigns each variable to the session info
		Integer currentNum = (Integer) sesh.getAttribute("number");
		String currentCity = (String) sesh.getAttribute("city");
		String currentPerson = (String) sesh.getAttribute("person");
		String currentHobby = (String) sesh.getAttribute("hobby");
		String currentLivingThing = (String) sesh.getAttribute("livingThing");
		String currentNice = (String) sesh.getAttribute("nice");
		
		// adds the variables to the model
		model.addAttribute("showNum", currentNum);
		model.addAttribute("showCity", currentCity);
		model.addAttribute("showPerson", currentPerson);
		model.addAttribute("showHobby", currentHobby);
		model.addAttribute("showLivingThing", currentLivingThing);
		model.addAttribute("showNice", currentNice);
		
		
		return "show.jsp";
	}
		
}
